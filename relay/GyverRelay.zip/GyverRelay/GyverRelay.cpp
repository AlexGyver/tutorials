#include "GyverRelay.h"

GyverRelay::GyverRelay(boolean direction) {
	_direction = direction;
	output = _direction;   // выключить реле сразу
}

void GyverRelay::setDirection(boolean dir) {
	_direction = dir;
}

void GyverRelay::setDt(int dt) {
	_dt = dt;
	_dt_s = dt / 1000.0;
}

static int signum(float val) {
	return ((val > 0) ? 1 : ((val < 0) ? -1 : 0));
}

// вернёт выход, принимает время итерации в секундах
boolean GyverRelay::getResult() {
	float signal;
	if (k > 0) {
		float rate = (input - prevInput) / _dt_s;    // производная от величины (величина/секунду)
		prevInput = input;
		signal = input + rate * k;
	} else {
		signal = input;
	}

	// жуткая функция реле из лекций по ТАУ
	int8_t F = (signum(signal - setpoint - hysteresis / 2) + signum(signal - setpoint + hysteresis / 2)) / 2;

	if (F == 1) output = _direction;
	else if (F == -1) output = !_direction;
	return output;
}

boolean GyverRelay::getResultTimer() {
	if (millis() - prevTime > _dt) {
		prevTime = millis();
		getResult();
	}
	return output;
}

boolean GyverRelay::getResultNow() {
	setDt(millis() - prevTime);
	prevTime = millis();
	return getResult();
}